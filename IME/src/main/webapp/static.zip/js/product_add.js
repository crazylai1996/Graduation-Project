//产品上市时间日期选择
laydate.render({
  elem: '.product-ttm',
  type: 'month',
  format: 'yyyy年MM月',
  theme: '#CC99CC'
});
