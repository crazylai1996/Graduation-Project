$(".portrait-wrapped").hover(function(){
  $(this).find(".change-protrait").show();
},function(){
  $(this).find(".change-protrait").hide();
});
